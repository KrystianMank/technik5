package com.example.mobile;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText numerPraniaEditText;
    private TextView numerPraniaTextView, statusTextView;
    private Button zatwierdzButton, wlaczButton;
    private int numerPrania;
    private boolean czyKliknieto = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        numerPraniaEditText = findViewById(R.id.numerPraniaEditText);
        numerPraniaTextView = findViewById(R.id.numerPraniaTextView);
        statusTextView = findViewById(R.id.statusTextView);
        zatwierdzButton = findViewById(R.id.zatwierdzButton);
        wlaczButton = findViewById(R.id.wlaczButton);

        zatwierdzButton.setOnClickListener(v->{
            numerPrania = Integer.parseInt(numerPraniaEditText.getText().toString());
            if(numerPrania >= 1 && numerPrania <= 12){
                numerPraniaTextView.setText("Numer prania: "+numerPrania);
            }
            else{
                numerPraniaTextView.setText("Numer prania: nie podano");
            }
        });

        wlaczButton.setOnClickListener(v->{
            czyKliknieto = !czyKliknieto;
            if(czyKliknieto){
                wlaczButton.setText("Wyłącz");
                statusTextView.setText("Odkurzacz włączony");
            }
            else{
                wlaczButton.setText("Włącz");
                statusTextView.setText("Odkurzacz wyłączony");
            }
        });
    }
}